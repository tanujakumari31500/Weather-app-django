from django.apps import AppConfig


class MigrateConfig(AppConfig):
    name = 'migrate'
